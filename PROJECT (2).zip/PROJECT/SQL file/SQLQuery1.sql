use TRAINING_PROJECT
select*from[dbo].[sample store]
select*from[dbo].[sample store] order by Ship_Mode;
Alter Table [dbo].[sample store] drop column total_cost
select*from[dbo].[sample store] order by Order_Date
