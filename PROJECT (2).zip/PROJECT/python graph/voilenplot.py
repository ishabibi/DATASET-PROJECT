import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\admin\\Downloads\sample store.csv",encoding='latin1')
sns.set_style()
color_palette = sns.color_palette("husl", n_colors=len(df['Quantity'].unique()))

sns.violinplot(x='Quantity', y='Discount', data=df, hue='Quantity', legend=False, palette=color_palette)



plt.show()