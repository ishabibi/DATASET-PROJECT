import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt

# Define type_colors before using it
type_colors = ['#78C850', '#F08030', "#6890F0", '#A88820', '#A8A878', '#F8D030', '#EE99AC', '#C03028', '#F85888', '#88A038', '#705898', '#98D8D8', '#7038F8']

df = pd.read_csv("C:\\Users\\admin\\Downloads\sample store.csv",encoding='latin1')
sns.countplot(x='Quantity', data=df, palette=type_colors)
plt.xticks(rotation=-45)  # Correct the function name here
plt.show()