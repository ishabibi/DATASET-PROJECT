import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

df1 = pd.read_csv(r"C:\Users\admin\Downloads\sample store.csv", encoding="ISO-8859-1")

print(df1.head())

stats_df = df1.drop(['City', 'State', 'Postal_Code'], axis=1)
melted_df = pd.melt(stats_df, id_vars=["Region", "Sales", "Quantity"], var_name="stat")
print(melted_df.head())
color_palette = sns.color_palette('husl', n_colors=len(df1['Profit'].unique()))
x = np.sort(df1['State'])
y = np.arange(1, len(x)+1)/len(x)
g = plt.plot(x, y, marker='.', linestyle='none')
g = plt.xlabel('')
g = plt.ylabel('ECDF')
plt.margins(0.02)



plt.show()