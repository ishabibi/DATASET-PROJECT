
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("C:\\Users\\admin\\Downloads\sample store.csv",encoding='latin1')
print(df.head())


sns.lmplot(x='Sales', y='Profit', data=df)


plt.show()